
DATA_0D8F49:
	%SPO_SpriteScriptOp40_UnknownOpcode($01, $00090E, DATA_0D8F62)
	%SPO_SpriteScriptOp3E_UnknownOpcode($24)
DATA_0D8F51:
	%SPO_SpriteScriptOp0E_UnknownOpcode()
	%SPO_SpriteScriptOp46_UnknownOpcode($F0)
	%SPO_SpriteScriptOp3E_UnknownOpcode($40)
	%SPO_SpriteScriptOp0E_UnknownOpcode()
	%SPO_SpriteScriptOp42_UnknownOpcode()
	%SPO_SpriteScriptOp0E_UnknownOpcode()
	%SPO_SpriteScriptOp46_UnknownOpcode($10)
	%SPO_SpriteScriptOp3E_UnknownOpcode($24)
	%SPO_SpriteScriptOp0E_UnknownOpcode()
	%SPO_SpriteScriptOp44_UnknownOpcode()
	%SPO_SpriteScriptOp38_UnknownOpcode(DATA_0D8F51)

DATA_0D8F62:
	%SPO_SpriteScriptOp3E_UnknownOpcode($24)
DATA_0D8F64:
	%SPO_SpriteScriptOp42_UnknownOpcode()
	%SPO_SpriteScriptOp0E_UnknownOpcode()
	%SPO_SpriteScriptOp46_UnknownOpcode($F0)
	%SPO_SpriteScriptOp3E_UnknownOpcode($40)
	%SPO_SpriteScriptOp0E_UnknownOpcode()
	%SPO_SpriteScriptOp44_UnknownOpcode()
	%SPO_SpriteScriptOp0E_UnknownOpcode()
	%SPO_SpriteScriptOp46_UnknownOpcode($10)
	%SPO_SpriteScriptOp3E_UnknownOpcode($24)
	%SPO_SpriteScriptOp0E_UnknownOpcode()
	%SPO_SpriteScriptOp38_UnknownOpcode(DATA_0D8F64)

DATA_0D8F75:
	%SPO_SpriteScriptOp00_UnknownOpcode()
	%SPO_SpriteScriptOp40_UnknownOpcode($4E, $000900, DATA_0D8F75)
	%SPO_SpriteScriptOp32_UnknownOpcode($00, $000A20)
	%SPO_SpriteScriptOp30_UnknownOpcode()

DATA_0D8F81:
	%SPO_SpriteScriptOp32_UnknownOpcode($80, $00093E)
	%SPO_SpriteScriptOp40_UnknownOpcode($01, $00090E, DATA_0D8F96)
	%SPO_SpriteScriptOp4A_UnknownOpcode($0B11)
	%SPO_SpriteScriptOp4C_UnknownOpcode($A1)
DATA_0D8F90:
	%SPO_SpriteScriptOp06_UnknownOpcode()
	%SPO_SpriteScriptOp32_UnknownOpcode($00, $00093E)
	%SPO_SpriteScriptOp30_UnknownOpcode()

DATA_0D8F96:
	%SPO_SpriteScriptOp4A_UnknownOpcode($0D10)
	%SPO_SpriteScriptOp4C_UnknownOpcode($A2)
	%SPO_SpriteScriptOp38_UnknownOpcode(DATA_0D8F90)
Disassembly has ended at $0D8F9E
